function StageAssistant() {
}

StageAssistant.prototype.setup = function() {
    this.controller.pushScene("schedule");
}
